HEIGHT = 520
WIDTH = 900
MENU_WIDTH = 250
BUTTON_HEIGHT = 50
BUTTON_WIDTH = 150
FRAME_COLOR ='#a3f9da'
MENU_COLOR = '#aaf0d1'
BUTTON_COLOR = '#d4a3e1'

MBTI_MATE = './mbti_mate.csv'
QUESTIONS = './questions.txt'
STUDENTS = './mbti_student.csv'
RELATION_IMG_PATH = './relations/Relations_'

MATE={
3:'이성적인 관계',
2: '끈끈한 관계',
1: '잠재적 관계',
0: '갈등관계',
-1: '맞지 않는 관계'}

MBTI_KIND = ['E / I', 'S / N', 'T / F', 'J / P']
