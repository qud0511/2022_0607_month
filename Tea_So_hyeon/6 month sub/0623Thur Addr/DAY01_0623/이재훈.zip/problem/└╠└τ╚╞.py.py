
phone_list = []

#def checkBook():
    ## 처음엔 어떻게 폴더 내에 있는 파일의 이름을 확인하는지 모르겠습니다.... ##
    ## 폴더 내에 파일 수를 읽을 수 있는 방법만 있더라도
    ## for i in range(0, len(folder)? :
    ## phone_list.append(folder[i]) 식으로 할 수 있을 것 같은데 이 이상은 모르겠습니다... 죄송합니다

def mainEvent():
    main_text = "\n=== 나의 주소록 === \n1. 전 체 보 기 \n2. 검      색 \n3. 추      가 \n4. 종      료\n================="
    print(main_text)
    num_Choice = input("\n원하는 기능을 입력해 주세요 : ")
    if num_Choice == '1':
        event01()
    elif num_Choice == '2':
        event02()
    elif num_Choice == '3':
        event03()
    elif num_Choice == '4':
        event04()
    else:
        print("\n잘못된 번호를 선택하셨습니다.\n")
        mainEvent()

def event01():
    print("\n전체보기를 선택하셨습니다.\n")

    if len(phone_list) == 0:
        print("\n아직 주소록에 아무런 정보가 없습니다.\n")

    else :
        for i in range(0, len(phone_list)):
            print(phone_list[i])
            i += 1
    mainEvent()

def event02():
    print("\n검색를 선택하셨습니다.\n")
    key_Word = input("\n검색어를 입력하세요 : ")
    j = 0
    for j in range(0,len(phone_list)) :
        if key_Word in phone_list[j] :
            print("파일명 : " + phone_list[j])
            filename = phone_list[j] + '.txt'
            with open('./AddressBook/' + filename, mode='r', encoding='utf=8') as file:
                text = file.read()
                print(text)
    mainEvent()

def event03():
    print("\n추가를 선택하셨습니다.")
    name = input("\n추가할 사람의 이름을 입력해주세요 : ")
    num_phone = input("\n추가할 사람의 전화번호를 입력해주세요 : ")

    filename = name + '_' + num_phone[-4:]
    phone_list.append(filename)
    file ='./AddressBook/' + filename + '.txt'
    filename = open(file, mode='w', encoding='utf=8')
    filename.write(name)
    filename.write(' ')
    filename.write(num_phone)
    #filename.write(' ')
    #filename.write(inf_0)
    #filename.write(' ')
    #filename.write(inf_1)
    filename.close()
    mainEvent()

def event04():
    print("\n종료를 선택하셨습니다.\n")

mainEvent()
