import ex_func

if __name__ == '__main__':
    ex_func()