with open('ex_info.txt', mode='r', encoding='utf-8') as s:
    with open('ex_menu.txt', mode='r', encoding='utf-8') as m:
        textAll=[]
        for line in s.readlines():
            textAll.append(line.replace('\n', ''))
        menu=m.read()

while True:
    print('\n'+menu)
    n = int(input())
    if n==1:
        print(*textAll, sep='\n', end='\n\n')
    elif n==2:
        search=input('\n'+'검색 단어 : ')
        keyword=search.split()
        result=[]
        for line in textAll:
            for k in keyword:
                if k in line:
                    result.append(line)
        if result:
            print('\n')
            print(*result, sep='\n', end='\n\n')
    elif n==4:
        break
    else:
        print('Invalid number')
        break