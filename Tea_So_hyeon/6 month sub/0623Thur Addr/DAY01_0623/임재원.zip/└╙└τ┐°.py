import os.path


def main_menu():
    print(f'==========나의 주소록==========')
    print(f'{"1. 전체보기 : 1번":^26}')
    print(f'{"2. 검   색 : 2번":^27}')
    print(f'{"3. 추   가 : 3번":^27}')
    print(f'{"4. 종   료 : 4번":^27}')
    print(f'=============================')


def menu_3():
    address_info = input(f'이름, 전화번호, 지역을 입력해주세요(","로 구분) : ')
    address_info_split = address_info.split(',')
    filename = r'./address_book/' + address_info_split[0]+'_'+address_info_split[1]+'.txt'
    file = open(filename, mode='a', encoding="UTF-8")
    file.write(address_info)
    file.close()


def menu_1():
    path = "./address_book"
    file_list = os.listdir(path)
    print(f'==========파일 리스트==========')
    for i in range(len(file_list)):
        print(f'{file_list[i]}')
    print(f'=============================')         # 폴더에서 파일 리스트 불러오는건 어떻게 할지 모르겠어서 import os 모듈 사용했습니다.


def menu_2():
    name = input(f'검색 이름 : ')
    path = "./address_book"
    file_list = os.listdir(path)
    for i in range(len(file_list)):
        if name in file_list[i]:
            print(f'파일명 : {file_list[i]}')
            file_open = r'./address_book/' + file_list[i]
            file = open(file_open, mode='r', encoding='UTF-8')
            line = file.read()
            print(f'{line}')


def menu_select():
    while True:
        main_menu()
        number = input(f'원하시는 메뉴를 숫자로 선택해 주세요. : ')
        if number == '1':
            menu_1()
        elif number == '2':
            menu_2()
        elif number == '3':
            menu_3()
        elif number == '4':
            print(f'프로그램을 종료합니다.')
            break
        else:
            print(f'없는 메뉴입니다. 다시 선택해주세요.')


menu_select()
