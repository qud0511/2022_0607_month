# AddressBook

이름: AddressBook
기능:
    - 전체보기
    - 검색
    - 추가
    - 종료
조건:
    - AddressBook으로 폴더 생성
    - 해당 폴더 존재 여부 확인 후 없으면 생성
    - 주소록 파일 생성한 것은 저장되도록 하기

구조:
    - sample_data
    - 마징가_2222.txt
    - readme.txt
    - addrbook.txt
    - test_addr_func.py
    - test_addr_main.py


## 중요사항
- 주소록 업데이트 기능 RuntimeError
  - test_addr_main.py(line 41~43)
    ... elif query==3:
    ... i={'name': '이름', 'local': '지역', 'phone':'연락처'}
    ... for k, v in i.items(): i.update({i[k]: input(v+' : ')})
    >>> RuntimeError: dictionary changed size during iteration
