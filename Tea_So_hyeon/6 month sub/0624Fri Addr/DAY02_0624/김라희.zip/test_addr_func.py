import re

"""test functions for AddressBook
test_addr_func consists of a function to check string data.

AddressBook is as:
1. Create the AddressBook folder if it doesn't exit
2. Search, find and add data if there is an AddressBook folder
"""

def test_chInt(value: str) -> int:
    """Convert string to number if it matches the pattern"""
    if isinstance(value, str):
        p=re.match('[1-4]', value)
        if p is not None:
            return int(p.group())


def test_hasSpc(*values: str) -> list:
    """Remove special characters and spaces from the string
    and return it as a list"""
    result, outcome = [], []
    for v in values:
        if isinstance(v, str):
            p=re.findall('([^!@ #$%^&*()+=`~?<>])', v)
            if p is not None:
               result.append(p)
    for r in result: outcome.append(''.join(r))
    return outcome


def test_chkword(*word: str) -> bool:
    """Return True if it is a word, otherwise False"""
    for w in word:
        if isinstance(w, str):
            p=re.match('([a-zA-Z]+)', w)
            if p is not None:
                 return True
            else: return False


def test_chkContact(contact: str) -> bool:
    """Return True when it is a specific pattern form, otherwise False"""
    if isinstance(contact, str):
        p=re.match('(\\d{3}-\\d{4}-\\d{4})', contact)
        if p is not None: return True
        else: return False