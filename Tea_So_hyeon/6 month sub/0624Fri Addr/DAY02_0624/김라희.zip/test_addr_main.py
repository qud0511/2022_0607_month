import os
import test_addr_func as ab


if __name__=="__main__":

    dirpath='../AddressBook/sample_data/'

    # 디렉토리/폴더 없으면 생성
    if not os.path.exists(dirpath):
        os.mkdir(dirpath)
    abdata=os.listdir(dirpath)

    # 주소록 조회 메뉴 파일 가져오기
    with open('./addrbook.txt', mode='r', encoding='utf-8') as q:
        qtable=q.read()

    # 1, 2, 3을 제외한 값을 받을 때까지 반복
    while True:
        # 주소록 조회 메뉴 보여주고 숫자 입력받기
        print(qtable, end='\n')
        query=input('Enter number : ')
        query=ab.test_chInt(query)

        # 조건문 시작
        if query==4: break
        elif abdata and query==1:
            print()
            print(*abdata)

        # 주소록 검색
        elif query==2:
            keyword=input('\n검색 입력 : ')
            for d in abdata:
                if keyword in d:
                    print('파 일 명 : {}.format(d)')
                    with open(dirpath+d, mode='r', encoding='utf-8') as f:
                        print('정   보 :\n{}'.format(f.read()))

        # 주소록 업데이트
        elif query==3:
            i={'name': '이름', 'local': '지역', 'phone':'연락처'}
            for k, v in i.items(): i.update({i[k]: input(v+' : ')})
            # 유효 입력값 검증 후 Addressbook 폴더에 추가
            if ab.test_chkword(i['name'], i['local']) and ab.test_chkContact(i['phone']):
                filename=i['name']+'_'+i['local'][-4:]+'.txt'
                with open(dirpath+filename, mode='w', encoding='utf-8') as f:
                    f.write(i['name']+' :'+i['local']+' :'+i['phone'])

        # 1, 2, 3이 아닐 경우 메시지 출력 후 종료
        else:
            print('\nAddressBook has no data for value just entered')
            break