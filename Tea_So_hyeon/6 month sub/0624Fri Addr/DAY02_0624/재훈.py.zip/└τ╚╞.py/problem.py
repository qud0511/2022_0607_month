# --------------------------------------------------
# PROGRAM : addressBook_APP
# DESCRIPTION : File I/O 처리, str 데이터 처리, Function 실습
# 조건 (1) AddressBook 폴더에 개인 파일 생성 => 이름_전화번호.txt
# 조건 (2) 보기, 검색, 추가, 종료 기능
# 조건 (3) 종료 입력 전까지 무한 반복
# --------------------------------------------------

import os
import os.path as path

# 전역 변수 및 상수 선언 -------------------------------
DIR_PATH = './AddressBook/'     # 파일 저장 폴더 경로


# 함수 정의 ------------------------------------------

# 메뉴 출력 함수 -------------------------------------
# 함수명 : showMenu
# 파라미터 : none
# 리턴값 : none
# --------------------------------------------------

def showMenu():
    print('='*3 +'ADDRESSSBOOK' + 3*'=')
    print(' '*2 +'1. 전 체 보 기')
    print(' '*2 +'2. 검      색')
    print(' '*2 +'3. 추      가')
    print(' '*2 +'4. 종      료')
    print('='*18)

# 전체보기 함수 -------------------------------------
# 함수명 : allAddress
# 파라미터 : none
# 리턴값 : none
# --------------------------------------------------
def showAddress():
    for addr in os.listdir(DIR_PATH):
        print(addr[:-4])

# 검색 후 정보 출력 함수 -------------------------------------
# 함수명 : searchAddress
# 파라미터 : name / phone_number str data
# 리턴값 : none
# --------------------------------------------------
def searchAddress(name_phone):
    # ADD_List 안에서 해당 검색어의 존재 여부를 체크
    for add in os.listdir(DIR_PATH):
        if name_phone in add:
            print(f'파일명 : {add}')
            with open(DIR_PATH+add, mode='r', encoding='utf-8') as f:
                print(f'정  보 : {f.read()}')

# 주소록 파일 생성 및 추가 -------------------------------------
# 함수명 : addAddress
# 파라미터 : 이름, 전화번호, 지역 등등
# 리턴값 : none
# --------------------------------------------------

def addAddress(name, phone, loc, email):
    txt_phone = phone[-4:]
    filename = name + '_' + txt_phone + '.txt'
    # 파일명 리스트 추가
    os.listdir(DIR_PATH).append(filename)
    # AddressBook 폴더에 파일 생성
    with open(DIR_PATH + filename, mode='w', encoding='utf-8') as f:
        f.write(name + ' ' + phone + ' ' + loc + ' ' + email)

#프로그램 초기화 함수 -------------------------------------------
# ADD_LIST에 AddressBook안에 존재하는 파일 리스트 정보를 추가
# 함수명 : initApp
# 파라미터 : none
# 리턴값 : none
# --------------------------------------------------

def initApp():
    if not os.path.exists(DIR_PATH):
        os.mkdir(DIR_PATH)
# 기능 구현 ------------------------------------------

print('------ 프로그램 시작 -------')
initApp()
while True:
    showMenu()
    #  사용자로부터 메뉴 선택 받기
    select = input("메뉴 선택 : ")
    if select == '4': break
    elif select == '1':
        showAddress()
    elif select == '2':
        searchAddress(input("검색어를 입력해주세요 : "))
    elif select == '3':
        search = input("이름 전화번호 지역 e-mail을 입력해주세요 : ").split(',')
        addAddress(search[0], search[1], search[2], search[3])
    else:
        print("해당 메뉴는 존재하지 않습니다.")
print('------ 프로그램 종료 -------')

